package org.ape.data.core.io.impl;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.ape.data.core.util.Import;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class CSVImporter implements Import{

	@Override
	public void importFromRemoteByFtp() {
		
	}

	@Override
	public void split() {
		
		
	}

	@Override
	public void processStreaming() {
		
	}

	@Override
	public void storeMeta() {
		
	}

	@Override
	public void storeInfo() {
		
		
	}
	
	private static final String ADDRESS_FILE="sss.csv";
	 public static void main(String[] args) throws IOException {
//       CSVWriter writer = new CSVWriter(new FileWriter("sss.csv"));
//	       List<String[]> allElements = new ArrayList<String[]>();
//	        allElements.add(new String[]{"张三","地址1","邮箱1"});
//	         allElements.add(new String[]{"李四","地址2","邮箱2"});
//	        writer.writeAll(allElements);
//	        writer.close();
//	         System.out.println("\nGenerated CSV File:" + ADDRESS_FILE);
//	        
	         CSVReader reader = new CSVReader(new FileReader(ADDRESS_FILE));
	         String [] nextLine;
	        while ((nextLine = reader.readNext()) != null) {
	             System.out.println("["+nextLine[0]+"]\n["+nextLine[1]+"]\n["+nextLine[2]+"]\n["+nextLine[3]+"]");
	         }
	    }

}
