package org.ape.data.core.storage;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MetaStore {
	
	@Resource
	private MySqlBaseDao dao;
	
	@Transactional(propagation=Propagation.REQUIRED)
	public  void storeMetaData(String userName,String projName,Map<String,String> column,String type){
		createUserTable(userName,projName,column);
		StringBuffer sb = new StringBuffer("insert into META_SCHEMA(USERNAME,PROJECT,COLOM,TYPE) values('"+userName+"','"+projName+"','");
	   	for (Map.Entry<String, String> m : column.entrySet()){ 
	   		   sb.append(m.getKey()+" "+m.getValue()+",");
	   		   } 
		dao.update(sb.toString());
	}
	

    public  void createUserTable(String userName,String projName,Map<String,String> column){
    	StringBuffer sb = new StringBuffer("create table t_"+userName+"_"+projName+"( id bigint auto_increment not null primary key,");
    	 for (Map.Entry<String, String> m : column.entrySet()){ 
    		   sb.append(m.getKey()+" "+m.getValue()+",");
    		   } 
    	  String sql = sb.substring(0, sb.length()-1)+")";
    	  dao.update(sql);
	}

//    public static void main(String[] args) {
//    	Map<String,String> column = new HashMap<String,String>();
//    	column.put("DDDD", "VARCHAR");
//    	column.put("DDDDSS", "VARCHAR2");
//    	storeMetaData("yushh","yushh",column,"hadoop");
//	}
}
