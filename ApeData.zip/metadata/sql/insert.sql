use demo;

insert into t_bank(id,bank_name) values(1,'bea');